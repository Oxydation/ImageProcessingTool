
package sunw.demo.quote;

interface QuoteListenerGUI 
{
  void quoteChanged(QuoteEvent x);
  void statusChanged(StatusEvent x);
}
